## Context

Part of #{{PARENT}}. The model stage in #{{MODEL}} has to ask a model whether a message is spam and, when it is, which spam subcategory from the parent's table it belongs to. The intended mechanism is a **Decisions API**: an endpoint that answers a closed set of choices with a probability for each option, rather than with free text. OpenAI and OpenRouter both expose one, and both are pre-release. What is known about either so far comes from secondhand reports rather than from the providers' own references, so nothing about request shape, model names, pricing, or data terms is assumed here. This issue produces that knowledge, and #{{MODEL}} waits on it.

### What the SDKs support today

Checked on 2026-10-24 by inspecting the published NuGet packages for any `Decision` type, member, or endpoint string. The pinned versions were checked, and so was the newest release of each:

| Package | Pinned | Newest | Decisions API |
|---|---|---|---|
| `OpenAI` (openai-dotnet) | 2.14.0 | 2.14.0 | None: no client, no model type, no `/decisions` route. The SDK's own tracker has an open feature request for it (openai/openai-dotnet#1434), which reports that other OpenAI SDKs already ship `client.decisions` |
| `Microsoft.Extensions.AI.Abstractions` / `.OpenAI` | 10.10.1 | 10.11.0 | None. The abstraction is `IChatClient` and `IEmbeddingGenerator`, and a decision is neither |
| `Microsoft.Agents.AI` / `.OpenAI` (Agent Framework) | 1.24.0 | 1.26.0 | None. The only "decision" in it is the tool-approval decision, which is unrelated |

So a Decisions API call from this stack is a hand-written HTTP request, at least until openai-dotnet ships a client. The bigger consequence is what such a call bypasses. Everything this deployment wraps around a model call hangs on `IChatClient`:

- the budget (`BudgetedChatClient`);
- retries and failure classification (`ResilientChatClient`, `ProviderCallFailureClassification`);
- run cost reporting under ADR 0022;
- the evaluation suite's answer cache, keyed on chat messages and `ChatOptions`.

A Decisions adapter outside `IChatClient` gets none of these for free. The ADR therefore decides whether the adapter re-implements them, whether a decision is wrapped so that it passes through them, or whether the stage uses chat completion with a constrained answer, which keeps every one of them.

OpenRouter's endpoint is reported at `/api/alpha/decisions` with a different request shape (a `state` plus `questions`). That rests on a single secondhand source and is unverified. The status of OpenAI's own endpoint is also reported inconsistently, from limited preview through public beta to generally available, and the official pages could not be reached from where this was written.

A closed answer is worth having for two reasons specific to this stage. A message is adversarial text, and a model that can only pick an option cannot be talked into writing something else. A probability per option is also a score that a threshold can judge, which is the shape a classification already records in `SpamAssessment`.

The questions that need an answer before #{{MODEL}} is written:

1. **Fitness.** Do the API's question types cover what the stage needs: a spam verdict, and on spam one subcategory out of six; for phishing, what is being asked for (credentials, payment details, one-time code); and for phishing and business email compromise, whom the message impersonates (which may need free text the API does not allow)?
2. **Status and portability.** What is each provider's release status and stability commitment, and how far apart are the two request shapes? Can the stage run without the Decisions API, for example over chat completion with a constrained answer through the existing OpenAI-compatible adapter, and should it? ADR 0011 already governs reaching a provider outside the OpenAI wire protocol.
3. **Where it runs.** Can a self-hosted or local model serve the same contract? If not, enabling the stage sends every classified message to a third party, which is a different privacy posture from the scanner it replaces, since the scanner ran inside the deployment.
4. **What leaves the deployment.** Headers, body text, link targets, attachment names. Redaction weakens phishing detection the same way it weakened the scanner, so what is sent unredacted, and under which new egress point in the [sensitive-content register](https://github.com/fathomise/MailFathom/blob/main/docs/features/sensitive-content-scanning.md#the-guarded-egress-points)?
5. **Provider terms.** Retention, training use, data-processing terms, and region, for each provider considered.
6. **Cost and reporting.** Cost per classified message at the bound #{{MODEL}} will set, and how a call is reported under ADR 0022.

## User stories

**As the owner** I want the Decisions API verified against the stage's needs before code depends on it, **so that** an alpha API does not shape a contract it cannot keep.

**As the operator of a deployment** I want a written decision on what the model stage sends and to whom, **so that** I know what enabling it means for my users' mail.

## Acceptance

- An ADR under `docs/decisions/`, approved by the owner, answers each of the six questions above.
- The ADR names the egress point the stage's input crosses and states what is sent unredacted.
- The ADR states whether the stage needs the Decisions API or also runs over chat completion, and what an operator configures in each case.
- The ADR states how the call is made while no SDK ships a client, and how it gets the budget, the retry and failure classification, the cost report, and the evaluation cache that today come through `IChatClient`.
- The SDK table above is re-checked against the versions pinned when the ADR is written.
- Anything the decision adds to `THIRD_PARTY_LICENSES.md` (a provider service or terms) is recorded.

## Dependencies

None. #{{MODEL}} waits on this.

## Baseline

1d26b66df368199d215814baacb461e90f902748
